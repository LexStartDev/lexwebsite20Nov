var myApp = angular.module('esopApp', []);

myApp.directive('fileModel', ['$parse', function ($parse) {
	return {
		restrict: 'A',
		link: function (scope, element, attrs) {
			var model = $parse(attrs.fileModel);
			var modelSetter = model.assign;

			element.bind('change', function () {
				scope.$apply(function () {
					modelSetter(scope, element[0].files[0]);
				});
			});
		}
	};
}]);

myApp.service('fileUpload', ['$rootScope', '$http', function ($rootScope, $http) {
	this.uploadFileToUrl = function (file, email, fileType, uploadUrl) {
		var fd = new FormData();
		fd.append("email", email);
		fd.append("fileType", fileType);
		fd.append('file', file);
		$http.post(uploadUrl, fd, {
			transformRequest: angular.identity,
			headers: { 'Content-Type': undefined }
		})
			.then(function (response) {
				console.log("success");
				$('.tab-content').css({ "opacity": 1, "pointer-events": "visible" });
				$(".loader2").css("display", "none");
				$('#makePayment').css("cursor", "pointer");
				$rootScope.makePay = true;


			})
			.catch(function () {
				console.log("error");
			});
	}
}]);

myApp.controller('myCtrl', ['$rootScope', '$scope', '$http', 'fileUpload', '$window', function ($rootScope, $scope, $http, fileUpload, $window) {
	// $('.nav li').not('.active').addClass('disabled');
	// $('.nav li').not('.active').find('a').removeAttr("data-toggle");
	$scope.kycDetails = {};
	$scope.kycDetails.docs;
	$scope.files = [];
	$scope.error = false;
	$rootScope.makePay = false;
	$rootScope.payment = false;
	$scope.throughReference = false;
	// $('#userAlreadyExistsModal').modal('show');

	$('#address2').css("display", "none");
	$('#sameAdd2[value="no"]').on('change', function () {
		$('#address2').show();
	});
	$('#sameAdd[value="yes"]').on('change', function () {
		$('#address2').hide();
	});
	$scope.kycDetails.hasDsc = true;
	$scope.refresh = function () {
		$window.location.reload();
	}

	updatepayment();
	function updatepayment() {
		if (localStorage.getItem("paymentdetails")) {
			var data = (localStorage.getItem("paymentdetails"));
			data = JSON.parse(data);

			var payload = {
				amount: data.payment_request.amount,
				email: data.payment_request.email,
				paid: 'true'

			}
			$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/updatePayment', payload).then(function (response) {
				setTimeout(function () {
					$window.localStorage.clear();
					$window.location.href = 'http://www.lexstart.com/';
				}, 2500);
			}).catch(function (params) {
				console.log('error');
				$window.localStorage.clear();
			})
		}
	}

	//function on the click of next button
	$scope.submitKycDeatils = function () {
		console.log("KycDetails: " + JSON.stringify($scope.kycDetails));

		$scope.email = {
			email: $scope.kycDetails.emailId
		}

		//http call for matching email 		
		$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/findByEmail', $scope.email).then(function (response) {
			// alert("response: " + JSON.stringify(response.data));
			$scope.kycData = response;
			console.log("................." + JSON.stringify($scope.kycDetails));
			$scope.kycDetails.status = "In progress";

			if ($scope.kycData.data.length === 1) {
				if ($(".nav-tabs").find("li.active a").text() == "Personal Details" && $scope.throughReference == false) {
					// alert("User already exists");
					$('#userAlreadyExistsModal').modal('show');
					return;
				}
				if ($(".nav-tabs").find("li.active a").text() == "Personal Details") {
					var request = {
						_id: $scope.id,
						details: $scope.kycDetails
					}
					$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
						// alert('details updated' + JSON.stringify(response.data));
						$(".next-text").parents(".tab-wrapper").find(".nav-tabs li.active").removeClass('active').next().addClass('active')
						$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active").removeClass('active').next().addClass('active')
						$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active a").next().attr("data-toggle")
						if ($('#Payment').hasClass('active')) {
							$('#makePayment').css({ "display": "inline-block" })
							$('#next').css({ "display": "none" })
						}
						if ($(".nav-tabs").find("li.active a").text() == "KYC Details") {
							// alert("inside kyc");
							$("#file").hide();
							$("#next").show();
						}
						else if ($(".nav-tabs").find("li.active a").text() == "Upload Documents") {
							// alert("inside upload");
							$("#file").show();
							$("#next").hide();
						}
						else if ($(".nav-tabs").find("li.active a").text() == "Payment") {
							// alert("inside upload");
							$("#file").hide();
							$("#makePayment").show();
						}



					}).catch(function (error) {
						console.log('error while updating details: ' + JSON.stringify(error));
					});
				}
				else if ($(".nav-tabs").find("li.active a").text() == "KYC Details") {
					$scope.invalidAadhaar = false;
					$scope.noAadhaar = false;
					$scope.noDin = false;
					$scope.noAddress = false;
					validateDin();
					validateAddress();
					if ($scope.kycDetails.residentDirector) {
						validateAadhaar();
					}

					function validateAadhaar() {
						var aadhaar = $scope.kycDetails.aadhaarNumber;
						if (aadhaar == undefined) {
							$scope.noAadhaar = true;
						}
						var aadhaarValid = aadhaar.replace(/[^\d]/g, '');
						// alert(aadhaarValid);
						if (aadhaarValid.length == 12) {
							// alert("true");
							$scope.invalidAadhaar = false;
						}
						else {
							// alert("false");
							$scope.invalidAadhaar = true;
						}
					}

					function validateDin() {
						var din = $scope.kycDetails.dinNumber;
						if (din == undefined || din == "") {
							$scope.noDin = true;
						}
					}

					function validateAddress() {
						var address = $scope.kycDetails.address;
						if (address == undefined || address == "") {
							$scope.noAddress = true;
						}
					}

					$scope.id = $scope.kycData.data[0]._id;

					if ($scope.invalidAadhaar == false && $scope.noAadhaar == false && $scope.noDin == false && $scope.noAddress == false) {
						var request = {
							_id: $scope.id,
							details: $scope.kycDetails
						}
						$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
							// alert('details updated' + JSON.stringify(response.data));
							$(".next-text").parents(".tab-wrapper").find(".nav-tabs li.active").removeClass('active').next().addClass('active')
							$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active").removeClass('active').next().addClass('active')
							$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active a").next().attr("data-toggle")
							if ($('#Payment').hasClass('active')) {
								$('#makePayment').css({ "display": "inline-block" })
								$('#next').css({ "display": "none" })
							}
							if ($(".nav-tabs").find("li.active a").text() == "KYC Details") {
								// alert("inside kyc");
								$("#file").hide();
								$("#next").show();
							}
							else if ($(".nav-tabs").find("li.active a").text() == "Upload Documents") {
								// alert("inside upload");
								$("#file").show();
								$("#next").hide();
							}
							else if ($(".nav-tabs").find("li.active a").text() == "Payment") {
								// alert("inside upload");
								$("#file").hide();
								$("#makePayment").show();
							}



						}).catch(function (error) {
							console.log('error while updating details: ' + JSON.stringify(error));
						});
					}
				}

			} else {
				$scope.temp = $scope.kycDetails.emailId;
				console.log($scope.temp);
				$scope.noEmail = false;
				$scope.nocontact = false;
				$scope.invalidEmail = false;
				$scope.invalidContact = false;
				validateEmail();
				validateContact();
				function validateEmail() {
					var y = $scope.temp;
					console.log(y);
					if (y == undefined) {
						// alert("Enter email address");
						$scope.noEmail = true;
					}
					var atpos2 = y.indexOf("@");
					var dotpos2 = y.lastIndexOf(".");
					if (atpos2 < 1 || dotpos2 < atpos2 + 2 || dotpos2 + 2 >= y.length) {
						// alert("invalid email");
						$scope.invalidEmail = true;
					}

				}
				function validateContact() {
					var phone = $scope.kycDetails.contactNumber;
					// console.log("=======: "+phone);
					if (phone == undefined || phone == "") {
						// alert("Enter contact number");
						$scope.nocontact = true;
					}
					// var phoneNum = phone.replace(/[^\d]/g, '');
					// if (phoneNum.length == 10) {
					// 	// alert("true");
					// }
					// else {
					// 	// alert("false");
					// 	$scope.invalidContact = true;
					// }
				}
				// return;
				if ($scope.invalidEmail == false && $scope.invalidContact == false && $scope.noEmail == false && $scope.nocontact == false) {
					//http call for saving form 
					$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/directorkycdetails', $scope.kycDetails).then(function (response) {
						// alert('details saved');
						$scope.hideNotes = true;

						//open director popup
						$('#directorModal').modal('show');

						$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/findByEmail', $scope.email).then(function (response) {
							// alert(JSON.stringify(response.data));
							// alert(response.data[0]._id);
							$rootScope.id = response.data[0]._id;
							var referenceNumber = response.data[0]._id;

							//reference number mail to client
							var payload = {
								// "to": $scope.kycDetails.emailId,
								// "subject": "LexStart Reference No.| Director KYC",
								// "html": "Thank you for registering with LexStart. Your reference no. is <b>"+ referenceNumber +"</b>. You can complete or update the KYC form or upload the documents required, at any time, by clicking <a href='http://lexstart.com/directorKycForm.html'>here</a> and entering the reference no.  <br> <br> Kind Regards	<br>LexStart Team",
								// "bcc": "false"
								name: response.data[0].name,
								email: response.data[0].emailId,
								referenceNo: response.data[0]._id
							}
							// alert(JSON.stringify(payload));
							// return;
							$http.post('http://dev.lexstart.in:3000/api/v2/kycRegistration', payload).then(function (response) {
								// alert("mail sent");
								$(".next-text").parents(".tab-wrapper").find(".nav-tabs li.active").removeClass('active').next().addClass('active')
								$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active").removeClass('active').next().addClass('active')
								$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active a").next().attr("data-toggle")

							}).catch(function (error) {
								alert("error while sending mail: " + JSON.stringify(error));
							});

						}).catch(function (error) {
							alert(error);
						});
					}).catch(function (error) {
						alert('error while saving details: ' + error);
					});
				}
			}
		}).catch(function (error) {
			console.log(error);
		});
	}


	////////////////////////File upload Validation for buttob proceed////////////////////////
	$scope.submitKycDeatils2 = function () {
		// alert("file wala inside" + JSON.stringify($rootScope.isIdentityproof));
		console.log($rootScope.isAddressProof);
		// if ($scope.kycDetails.aadhaar == true && $scope.kycDetails.addressProof == true && $scope.kycDetails.identityProof == true) {
		console.log("KycDetails2: " + JSON.stringify($scope.kycDetails));

		$scope.email = {
			email: $scope.kycDetails.emailId
		}

		//http call for matching email 		
		$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/findByEmail', $scope.email).then(function (response) {
			// alert("response: " + JSON.stringify(response.data));
			$scope.kycData = response;
			console.log("................." + JSON.stringify($scope.kycDetails));
			$scope.kycDetails.status = "In progress";
			if ($scope.kycData.data.length === 1) {

				$scope.id = $scope.kycData.data[0]._id;
				// alert($scope.id);
				var request = {
					_id: $scope.id,
					details: $scope.kycDetails
				}

				$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
					// alert('details updated' + JSON.stringify(response.data));
					$(".next-text").parents(".tab-wrapper").find(".nav-tabs li.active").removeClass('active').next().addClass('active')
					$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active").removeClass('active').next().addClass('active')
					$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active a").next().attr("data-toggle")
					if ($('#Payment').hasClass('active')) {
						$('#makePayment').css({ "display": "inline-block" })
						$('#next').css({ "display": "none" })
					}
					if ($(".nav-tabs").find("li.active a").text() == "KYC Details") {
						// alert("inside kyc");
						$("#file").hide();
						$("#next").show();
					}
					else if ($(".nav-tabs").find("li.active a").text() == "Upload Documents") {
						// alert("inside upload");
						$("#file").show();
						$("#next").hide();
					}
					else if ($(".nav-tabs").find("li.active a").text() == "Payment") {
						// alert("inside upload");
						$("#file").hide();
						$("#makePayment").show();
					}

				}).catch(function (error) {
					console.log('error while updating details: ' + JSON.stringify(error));
				});
			} else {
				$scope.temp = $scope.kycDetails.emailId;
				console.log($scope.temp);
				$scope.invalidEmail = false;
				$scope.invalidContact = false;
				validateEmail();
				validateContact();
				// validateFormcc();
				function validateEmail() {
					// alert("inside validate");
					var y = $scope.temp;
					console.log(y);
					var atpos2 = y.indexOf("@");
					var dotpos2 = y.lastIndexOf(".");
					if (atpos2 < 1 || dotpos2 < atpos2 + 2 || dotpos2 + 2 >= y.length) {
						// alert("invalid email");
						$scope.invalidEmail = true;
					}
				}
				function validateContact() {
					var phone = $scope.kycDetails.contactNumber;
					var phoneNum = phone.replace(/[^\d]/g, '');
					if (phoneNum.length == 10) {
						// alert("true");
					}
					else {
						// alert("false");
						$scope.invalidContact = true;
					}
				}
				// return;
				if ($scope.invalidEmail == false && $scope.invalidContact == false) {
					//http call for saving form 
					$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/directorkycdetails', $scope.kycDetails).then(function (response) {
						// alert('details saved');
						$scope.hideNotes = true;

						//open director popup
						$('#directorModal').modal('show');

						$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/findByEmail', $scope.email).then(function (response) {
							// alert(JSON.stringify(response.data));
							// alert(response.data[0]._id);
							$rootScope.id = response.data[0]._id;
							var referenceNumber = response.data[0]._id;

							//reference number mail to client
							var payload = {
								// "to": $scope.kycDetails.emailId,
								// "subject": "LexStart Reference No.| Director KYC",
								// "html": "Thank you for registering with LexStart. Your reference no. is <b>" + referenceNumber + "</b>. Our Compliance Team will be in touch with you for next steps. <br> <br> Kind Regards	<br>LexStart Team",
								// "bcc": "false"
								name: response.data[0].name,
								email: response.data[0].emailId,
								referenceNo: response.data[0]._id
							}
							$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/referenceEmail', payload).then(function (response) {
								// alert("mail sent");
								$(".next-text").parents(".tab-wrapper").find(".nav-tabs li.active").removeClass('active').next().addClass('active')
								$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active").removeClass('active').next().addClass('active')
								$(".next-text").parents(".tab-wrapper").find(".tab-content .tab-pane.active a").next().attr("data-toggle")
							}).catch(function (error) {
								alert("error while sending mail: " + error);
							});

						}).catch(function (error) {
							alert(error);
						});
					}).catch(function (error) {
						alert('error while saving details: ' + error);
					});
				}
			}
		}).catch(function (error) {
			console.log(JSON.stringify(error));
		});
		// } else {
		// 	// alert("Please upload required files");
		// 	$('#fileErrorModal').modal("show");
		// }
	}

	///////////////////////////////////file upload functions for all the documents/////////////////////////
	$scope.uploadFile1 = function (identityProof) {
		$('.tab-content').css({ "opacity": 0.4, "pointer-events": "none" });
		$(".loader2").css("display", "block");
		console.log(JSON.stringify(identityProof));
		$rootScope.isIdentityproof = identityProof;
		var file = $scope.identityProof;
		console.log('file is ' + JSON.stringify(file));
		var fileType = "identityProof";
		var email = $scope.kycDetails.emailId;
		var uploadUrl = "http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/uploadDocument";
		fileUpload.uploadFileToUrl(file, email, fileType, uploadUrl);

		if (file == undefined) {
			$('.tab-content').css({ "opacity": 1, "pointer-events": "visible" });
			$(".loader2").css("display", "none");
			// alert("No file Choosen");
			$(".no-file-selected1").css({ "display": "block", "color": "red" });

		} else {
			$(".no-file-selected1").css("display", "none");
			$scope.kycDetails.identityProof = true;
			var request = {
				_id: $scope.id,
				details: $scope.kycDetails
			}
			$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
				// alert("success identity proof");				
			}).catch(function (error) {
				alert(error);
			});
		}
	};

	$scope.uploadFile2 = function (addressProof) {
		$('.tab-content').css({ "opacity": 0.4, "pointer-events": "none" });
		$(".loader2").css("display", "block");
		$rootScope.isAddressProof = addressProof;
		var file = $scope.addressProof;
		console.log('file is ' + JSON.stringify(file));
		var fileType = "addressProof";
		var email = $scope.kycDetails.emailId;
		var uploadUrl = "http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/uploadDocument";
		fileUpload.uploadFileToUrl(file, email, fileType, uploadUrl);

		if (file == undefined) {
			$('.tab-content').css({ "opacity": 1, "pointer-events": "visible" });
			$(".loader2").css("display", "none");
			// alert("No file Choosen");
			$(".no-file-selected2").css({ "display": "block", "color": "red" });

		} else {
			$(".no-file-selected2").css("display", "none");
			$scope.kycDetails.addressProof = true;
			var request = {
				_id: $scope.id,
				details: $scope.kycDetails
			}
			$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
				// alert("success address proof");
			}).catch(function (error) {
				alert(error);
			});
		}
	};

	$scope.uploadFile3 = function () {
		$('.tab-content').css({ "opacity": 0.4, "pointer-events": "none" });
		$(".loader2").css("display", "block");
		var file = $scope.photo;
		// console.log('file is ' + JSON.stringify(file));
		var fileType = "passportSizePhoto";
		var email = $scope.kycDetails.emailId;
		var uploadUrl = "http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/uploadDocument";
		fileUpload.uploadFileToUrl(file, email, fileType, uploadUrl);

		if (file == undefined) {
			$('.tab-content').css({ "opacity": 1, "pointer-events": "visible" });
			$(".loader2").css("display", "none");
			// alert("No file Choosen");
			$(".no-file-selected3").css({ "display": "block", "color": "red" });

		} else {
			$(".no-file-selected3").css("display", "none");
			$scope.kycDetails.photo = true;
			var request = {
				_id: $scope.id,
				details: $scope.kycDetails
			}
			$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
				// alert("success photo");
			}).catch(function (error) {
				alert(error);
			});
		}
	};

	$scope.uploadFile4 = function () {
		$('.tab-content').css({ "opacity": 0.4, "pointer-events": "none" });
		$(".loader2").css("display", "block");
		var file = $scope.dscAppForm;
		// console.log('file is ' + JSON.stringify(file));
		var fileType = "DscApplicationForm";
		var email = $scope.kycDetails.emailId;
		var uploadUrl = "http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/uploadDocument";
		fileUpload.uploadFileToUrl(file, email, fileType, uploadUrl);

		if (file == undefined) {
			$('.tab-content').css({ "opacity": 1, "pointer-events": "visible" });
			$(".loader2").css("display", "none");
			// alert("No file Choosen");
			$(".no-file-selected4").css({ "display": "block", "color": "red" });

		} else {
			$(".no-file-selected4").css("display", "none");
			$scope.kycDetails.dscAppForm = true;
			var request = {
				_id: $scope.id,
				details: $scope.kycDetails
			}
			$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
				// alert("success dsc app form");
			}).catch(function (error) {
				alert(error);
			});
		}
	};

	$scope.uploadFile5 = function (aadhaar) {
		$('.tab-content').css({ "opacity": 0.4, "pointer-events": "none" });
		$(".loader2").css("display", "block");
		var file = $scope.aadhaar;
		// console.log('file is ' + JSON.stringify(file));
		var fileType = "aadhaar";
		var email = $scope.kycDetails.emailId;
		var uploadUrl = "http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/uploadDocument";
		fileUpload.uploadFileToUrl(file, email, fileType, uploadUrl);

		if (file == undefined) {
			$('.tab-content').css({ "opacity": 1, "pointer-events": "visible" });
			$(".loader2").css("display", "none");
			// alert("No file Choosen");
			$(".no-file-selected5").css({ "display": "block", "color": "red" });

		} else {
			// alert("else");
			$(".no-file-selected5").css("display", "none");
			$scope.kycDetails.aadhaar = true;
			var request = {
				_id: $scope.id,
				details: $scope.kycDetails
			}
			// alert(JSON.stringify(request));
			console.log(JSON.stringify(request));
			$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
				// alert("success aadhaar app form");
			}).catch(function (error) {
				alert(error);
			});
		}
	};

	$scope.uploadFile6 = function () {
		$('.tab-content').css({ "opacity": 0.4, "pointer-events": "none" });
		$(".loader2").css("display", "block");
		var file = $scope.passport;
		var fileType = "passport";
		var email = $scope.kycDetails.emailId;
		var uploadUrl = "http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/uploadDocument";
		fileUpload.uploadFileToUrl(file, email, fileType, uploadUrl);

		if (file == undefined) {
			$('.tab-content').css({ "opacity": 1, "pointer-events": "visible" });
			$(".loader2").css("display", "none");
			// alert("No file Choosen");
			$(".no-file-selected6").css({ "display": "block", "color": "red" });

		} else {
			$(".no-file-selected6").css("display", "none");
			$scope.kycDetails.passport = true;
			var request = {
				_id: $scope.id,
				details: $scope.kycDetails
			}
			$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request).then(function (response) {
				// alert("success dsc app form");
			}).catch(function (error) {
				alert(error);
			});
		}
	};

	/////////////////////////////////////pop up functions/////////////////////////////////
	$scope.residntDirector = function () {
		$scope.kycDetails.residentDirector = true;
		$scope.residentDirector = true;
		$scope.NonResidentDirector = false;
		// alert(JSON.stringify($scope.kycDetails));
		// alert($scope.id);
		var request1 = {
			_id: $rootScope.id,
			details: $scope.kycDetails
		}
		$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request1).then(function (response) {
			// alert('details updated' + JSON.stringify(response.data));
			$('#directorModal').modal('hide');
			$('#passportModal').modal('show');

		}).catch(function (error) {
			console.log('error while updating details: ' + JSON.stringify(error));
		});
	};

	$scope.nonResidntDirector = function () {
		$scope.kycDetails.residentDirector = false;
		$scope.NonResidentDirector = true;
		$scope.residentDirector = false;
		// alert(JSON.stringify($scope.kycDetails));
		// alert($scope.id);
		var request1 = {
			_id: $rootScope.id,
			details: $scope.kycDetails
		}
		$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request1).then(function (response) {
			// alert('details updated' + JSON.stringify(response.data));
			$('#directorModal').modal('hide');
			$('#dscModal').modal('show');

		}).catch(function (error) {
			console.log('error while updating details: ' + JSON.stringify(error));
		});
	};

	$scope.validPassport = function () {
		$scope.kycDetails.validPassport = true;

		var request1 = {
			_id: $rootScope.id,
			details: $scope.kycDetails
		}
		$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request1).then(function (response) {
			// alert('details updated' + JSON.stringify(response.data));
			$('#passportModal').modal('hide');
			$('#dscModal').modal('show');

		}).catch(function (error) {
			console.log('error while updating details: ' + JSON.stringify(error));
		});
	};

	$scope.noValidPassport = function () {
		$scope.kycDetails.validPassport = false;

		var request1 = {
			_id: $rootScope.id,
			details: $scope.kycDetails
		}
		$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request1).then(function (response) {
			// alert('details updated' + JSON.stringify(response.data));
			$('#passportModal').modal('hide');
			$('#dscModal').modal('show');

		}).catch(function (error) {
			console.log('error while updating details: ' + JSON.stringify(error));
		});
	};
	$scope.hasDsc = function () {
		$scope.yesDsc = true;
		$scope.noDsc = false;
		$scope.kycDetails.hasDsc = true;
		$scope.paymentAmount = 999;
		$scope.kycDetails.amountPaid = 999;
		// alert(JSON.stringify($scope.kycDetails));
		// alert($scope.id);
		var request1 = {
			_id: $rootScope.id,
			details: $scope.kycDetails
		}
		$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request1).then(function (response) {
			// alert('details updated' + JSON.stringify(response.data));
			$('#passportModal').modal('hide');
			// $('#dscModal').modal('show');
			$('#dscModal').modal('hide');

		}).catch(function (error) {
			console.log('error while updating details: ' + JSON.stringify(error));
		});
	};

	$scope.noDsc = function () {
		$scope.noDsc = true;
		$scope.yesDsc = false;
		$scope.kycDetails.hasDsc = false;
		$scope.paymentAmount = 2498;
		$scope.kycDetails.amountPaid = 2498;
		// alert(JSON.stringify($scope.kycDetails));
		var request1 = {
			_id: $rootScope.id,
			details: $scope.kycDetails
		}
		$http.put('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/upadteDetails', request1).then(function (response) {
			// alert('details updated' + JSON.stringify(response.data));
			$('#passportModal').modal('hide');
			// $('#dscModal').modal('show');
			$('#dscModal').modal('hide');

		}).catch(function (error) {
			console.log('error while updating details: ' + JSON.stringify(error));
		});
	};

	$scope.makePayment = function () {
		var payload = {
			purpose: 'Kyc_Payments',
			amount: $scope.kycDetails.amountPaid,
			// phone: org_phone
			buyer_name: $scope.kycDetails.name,
			redirect_url: window.location.origin + "/success.html",
			send_email: true,
			// send_sms: true,
			email: $scope.kycDetails.emailId,
			allow_repeated_payments: false
		};

		$http.post('http://dev.lexstart.in:3000/api/v2/get/payment-requests-prod/', payload)
			.then(function (res) {
				$window.localStorage.setItem("paymentdetails", JSON.stringify(res.data.payment_response));
				$window.location.href = res.data.payment_response.payment_request.longurl;
			})
			.catch(function (params) {
				console.log("error");
				$window.localStorage.clear();

			})
	}

	//function for existing user
	$scope.userForm = function () {
		// console.log("inside user form function: " + JSON.stringify($scope.referenceNumber));

		$scope.data = {
			referenceNumber: $scope.referenceNumber
		}
		// return;
		// console.log("reference number:"+JSON.stringify($scope.referenceNo));
		$http.post('http://lexstart-mattercode.eastus.cloudapp.azure.com:8443/api/findByReferenceNumber', $scope.data).then(function (response) {
			// alert(JSON.stringify(response));
			if (response.data.length == 0) {
				// alert("length 0");
				$scope.error = true;
			} else {
				// alert("length not 0");
				$scope.kycDetails = response.data[0];
				$scope.throughReference = true;
				$('#referenceModal').modal('hide');
			}

		}).catch(function (error) {
			// alert(JSON.stringify(error));
			$scope.error = true;
		});

	}

	$scope.coupon_value;
	$scope.calc_discount = function (coupon_value) {
		if (coupon_value == "KYCWLEX" && $rootScope.payment == false) {
			var temp = ($scope.kycDetails.amountPaid / 100) * 25;
			$rootScope.payment = true;
			$scope.kycDetails.amountPaid = $scope.kycDetails.amountPaid - temp;
			$('p.success').css("display", "block");
			$('p.invalid').css("display", "none");
		}
		else if (coupon_value != "KYCWLEX") {
			$('p.success').css("display", "none");
			$('p.invalid').css("display", "block");
		}
	}

	$scope.setFileID = function (element) {
		$scope.$apply(function ($scope) {
			$scope.file1 = element.files[0];
		});
	};
	$scope.setFileAC = function (element) {
		$scope.$apply(function ($scope) {
			$scope.file2 = element.files[0];
		});
	};
	$scope.setFileAP = function (element) {
		$scope.$apply(function ($scope) {
			$scope.file3 = element.files[0];
		});
	};
	$scope.setFilePass = function (element) {
		$scope.$apply(function ($scope) {
			$scope.file4 = element.files[0];
		});
	};
	$scope.setFilePP = function (element) {
		$scope.$apply(function ($scope) {
			$scope.file5 = element.files[0];
		});
	};
	$scope.setFileDSC = function (element) {
		$scope.$apply(function ($scope) {
			$scope.file6 = element.files[0];
		});
	};

}]);